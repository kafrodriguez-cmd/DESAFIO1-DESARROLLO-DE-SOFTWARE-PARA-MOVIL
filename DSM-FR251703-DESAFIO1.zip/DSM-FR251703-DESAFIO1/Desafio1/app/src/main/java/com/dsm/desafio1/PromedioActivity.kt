package com.dsm.desafio1

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import java.text.DecimalFormat

class PromedioActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etNota1: EditText
    private lateinit var etNota2: EditText
    private lateinit var etNota3: EditText
    private lateinit var etNota4: EditText
    private lateinit var etNota5: EditText

    private lateinit var btnCalcular: Button
    private lateinit var btnRegresar: Button

    private lateinit var tvResultado: TextView

    private val CHANNEL_ID = "PROMEDIO_CHANNEL"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_promedio)

        etNombre = findViewById(R.id.etNombre)

        etNota1 = findViewById(R.id.etNota1)
        etNota2 = findViewById(R.id.etNota2)
        etNota3 = findViewById(R.id.etNota3)
        etNota4 = findViewById(R.id.etNota4)
        etNota5 = findViewById(R.id.etNota5)

        btnCalcular = findViewById(R.id.btnCalcular)
        btnRegresar = findViewById(R.id.btnRegresar)

        tvResultado = findViewById(R.id.tvResultado)

        crearCanalNotificacion()
        solicitarPermisoNotificaciones()

        btnCalcular.setOnClickListener {
            calcularPromedio()
        }

        btnRegresar.setOnClickListener {
            finish()
        }
    }

    private fun calcularPromedio() {

        if (etNombre.text.toString().trim().isEmpty()) {
            etNombre.error = "Ingrese el nombre"
            etNombre.requestFocus()
            return
        }

        val nota1 = obtenerNota(etNota1) ?: return
        val nota2 = obtenerNota(etNota2) ?: return
        val nota3 = obtenerNota(etNota3) ?: return
        val nota4 = obtenerNota(etNota4) ?: return
        val nota5 = obtenerNota(etNota5) ?: return

        // Ponderaciones
        val promedio =
            (nota1 * 0.15) +
                    (nota2 * 0.20) +
                    (nota3 * 0.25) +
                    (nota4 * 0.20) +
                    (nota5 * 0.20)

        val formato = DecimalFormat("#.00")

        val estado = if (promedio >= 6.0) {
            "APROBÓ"
        } else {
            "REPROBÓ"
        }

        val resultado =
            "Estudiante: ${etNombre.text}\n" +
                    "Promedio: ${formato.format(promedio)}\n" +
                    "Estado: $estado"

        tvResultado.text = resultado
        enviarNotificacion(
            etNombre.text.toString(),
            formato.format(promedio),
            estado
        )
    }

    private fun obtenerNota(editText: EditText): Double? {

        val texto = editText.text.toString()

        if (texto.isEmpty()) {
            editText.error = "Campo obligatorio"
            editText.requestFocus()
            return null
        }

        val nota = texto.toDoubleOrNull()

        if (nota == null) {
            editText.error = "Ingrese un número válido"
            editText.requestFocus()
            return null
        }

        if (nota < 0 || nota > 10) {
            editText.error = "La nota debe estar entre 0 y 10"
            editText.requestFocus()
            return null
        }

        return nota
    }

    private fun solicitarPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                100
            )
        }
    }

    private fun crearCanalNotificacion() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val channel = NotificationChannel(
                CHANNEL_ID,
                "Promedio Estudiante",
                NotificationManager.IMPORTANCE_DEFAULT
            )

            val manager =
                getSystemService(Context.NOTIFICATION_SERVICE)
                        as NotificationManager

            manager.createNotificationChannel(channel)
        }
    }

    private fun enviarNotificacion(
        nombre: String,
        promedio: String,
        estado: String
    ) {

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Resultado Final")
            .setContentText("$nombre - Promedio: $promedio - $estado")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(
                this,
                "Permiso de notificaciones no concedido",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        NotificationManagerCompat.from(this).notify(1, builder.build())
    }
}