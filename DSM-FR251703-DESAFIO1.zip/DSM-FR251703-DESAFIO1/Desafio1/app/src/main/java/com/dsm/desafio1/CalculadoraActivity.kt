package com.dsm.desafio1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.FileOutputStream
import kotlin.math.pow
import kotlin.math.sqrt

class CalculadoraActivity : AppCompatActivity() {

    private lateinit var etNumero1: EditText
    private lateinit var etNumero2: EditText

    private lateinit var btnSumar: Button
    private lateinit var btnRestar: Button
    private lateinit var btnMultiplicar: Button
    private lateinit var btnDividir: Button
    private lateinit var btnPotencia: Button
    private lateinit var btnRaiz: Button
    private lateinit var btnRegresar: Button

    private lateinit var tvResultado: TextView

    private val archivoHistorial = "historial.txt"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        etNumero1 = findViewById(R.id.etNumero1)
        etNumero2 = findViewById(R.id.etNumero2)

        btnSumar = findViewById(R.id.btnSumar)
        btnRestar = findViewById(R.id.btnRestar)
        btnMultiplicar = findViewById(R.id.btnMultiplicar)
        btnDividir = findViewById(R.id.btnDividir)
        btnPotencia = findViewById(R.id.btnPotencia)
        btnRaiz = findViewById(R.id.btnRaiz)
        btnRegresar = findViewById(R.id.btnRegresarCalc)

        tvResultado = findViewById(R.id.tvResultadoCalc)

        btnSumar.setOnClickListener {
            operar("+")
        }

        btnRestar.setOnClickListener {
            operar("-")
        }

        btnMultiplicar.setOnClickListener {
            operar("*")
        }

        btnDividir.setOnClickListener {
            operar("/")
        }

        btnPotencia.setOnClickListener {
            operar("^")
        }

        btnRaiz.setOnClickListener {
            calcularRaiz()
        }

        btnRegresar.setOnClickListener {
            finish()
        }
    }

    private fun obtenerNumero1(): Double? {

        val texto = etNumero1.text.toString()

        if (texto.isEmpty()) {
            etNumero1.error = "Ingrese un número"
            return null
        }

        return texto.toDoubleOrNull().also {
            if (it == null) {
                etNumero1.error = "Ingrese un número válido"
            }
        }
    }

    private fun obtenerNumero2(): Double? {

        val texto = etNumero2.text.toString()

        if (texto.isEmpty()) {
            etNumero2.error = "Ingrese un número"
            return null
        }

        return texto.toDoubleOrNull().also {
            if (it == null) {
                etNumero2.error = "Ingrese un número válido"
            }
        }
    }

    private fun operar(operacion: String) {

        val num1 = obtenerNumero1() ?: return
        val num2 = obtenerNumero2() ?: return

        val resultado: Double

        when (operacion) {

            "+" -> {
                resultado = num1 + num2
            }

            "-" -> {
                resultado = num1 - num2
            }

            "*" -> {
                resultado = num1 * num2
            }

            "/" -> {

                if (num2 == 0.0) {
                    Toast.makeText(
                        this,
                        "No se puede dividir entre cero",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }

                resultado = num1 / num2
            }

            "^" -> {
                resultado = num1.pow(num2)
            }

            else -> return
        }

        val textoResultado = "$num1 $operacion $num2 = $resultado"

        tvResultado.text = textoResultado

        guardarHistorial(textoResultado)
    }

    private fun calcularRaiz() {

        val numero = obtenerNumero1() ?: return

        if (numero < 0) {

            Toast.makeText(
                this,
                "No existe raíz cuadrada de números negativos",
                Toast.LENGTH_LONG
            ).show()

            return
        }

        val resultado = sqrt(numero)

        val textoResultado = "√$numero = $resultado"

        tvResultado.text = textoResultado

        guardarHistorial(textoResultado)
    }

    private fun guardarHistorial(operacion: String) {

        try {

            val fos: FileOutputStream =
                openFileOutput(
                    archivoHistorial,
                    MODE_APPEND
                )

            fos.write(
                (operacion + "\n").toByteArray()
            )

            fos.close()

        } catch (e: Exception) {

            Toast.makeText(
                this,
                "Error al guardar historial",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}