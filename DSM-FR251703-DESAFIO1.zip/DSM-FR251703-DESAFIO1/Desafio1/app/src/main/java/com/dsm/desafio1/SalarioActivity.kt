package com.dsm.desafio1

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.RequiresPermission
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat

class SalarioActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var etSalario: EditText

    private lateinit var btnCalcular: Button
    private lateinit var btnRegresar: Button

    private lateinit var tvResultado: TextView

    private val formato = DecimalFormat("#,##0.00")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_salario)

        etNombre = findViewById(R.id.etNombreEmpleado)
        etSalario = findViewById(R.id.etSalarioBase)

        btnCalcular = findViewById(R.id.btnCalcularSalario)
        btnRegresar = findViewById(R.id.btnRegresarMenu)

        tvResultado = findViewById(R.id.tvResultadoSalario)

        btnCalcular.setOnClickListener {
            calcularSalario()
        }

        btnRegresar.setOnClickListener {
            finish()
        }
    }

    private fun calcularSalario() {

        val nombre = etNombre.text.toString().trim()
        val salarioTexto = etSalario.text.toString().trim()

        if (nombre.isEmpty()) {
            etNombre.error = "Ingrese el nombre"
            etNombre.requestFocus()
            return
        }

        if (salarioTexto.isEmpty()) {
            etSalario.error = "Ingrese un salario"
            vibrarDispositivo()
            etSalario.requestFocus()
            return
        }

        val salarioBase = salarioTexto.toDoubleOrNull()

        if (salarioBase == null) {
            etSalario.error = "Ingrese un número válido"
            vibrarDispositivo()
            etSalario.requestFocus()
            return
        }

        if (salarioBase <= 0) {
            etSalario.error = "El salario debe ser mayor que cero"
            vibrarDispositivo()
            etSalario.requestFocus()
            return
        }

        val afp = salarioBase * 0.0725
        val isss = salarioBase * 0.03
        val renta = calcularRenta(salarioBase)

        val totalDescuentos = afp + isss + renta
        val salarioNeto = salarioBase - totalDescuentos

        val resultado = """
            Empleado: $nombre
            
            Salario Base: $${formato.format(salarioBase)}
            
            AFP (7.25%): $${formato.format(afp)}
            ISSS (3%): $${formato.format(isss)}
            Renta: $${formato.format(renta)}
            
            Total Descuentos: $${formato.format(totalDescuentos)}
            
            Salario Neto: $${formato.format(salarioNeto)}
        """.trimIndent()

        tvResultado.text = resultado
    }

    private fun calcularRenta(salario: Double): Double {

        return when {

            salario <= 472.00 -> {
                0.0
            }

            salario <= 895.24 -> {
                ((salario - 472.00) * 0.10) + 17.67
            }

            salario <= 2038.10 -> {
                ((salario - 895.24) * 0.20) + 60.00
            }

            else -> {
                ((salario - 2038.10) * 0.30) + 288.57
            }
        }
    }

    @RequiresPermission(Manifest.permission.VIBRATE)
    private fun vibrarDispositivo() {

        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager =
                getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(
                    500,
                    VibrationEffect.DEFAULT_AMPLITUDE
                )
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(500)
        }
    }
}